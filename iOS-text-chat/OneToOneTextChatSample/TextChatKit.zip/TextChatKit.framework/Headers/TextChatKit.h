//
//  TextChatKit.h
//  TextChatKit
//
//  Created by Xi Huang on 3/30/16.
//  Copyright © 2016 Tokbox. All rights reserved.
//

#import <TextChatKit/TextMessage.h>
#import <TextChatKit/TextChatView.h>
#import <TextChatKit/TextChatUICustomizator.h>